public class Mage {
}
