public abstract class player implements Rasa{
    protected String name;
    protected double strength;
    protected int level;
    protected double intelligence;
    protected double dexterity;
    protected double endurance;
    protected double xp;
    protected int startingPoints = 5;
    protected double lifeCount = level * 10;
    protected int lvlUp = level * 100;

    public Character createRacism(int racismClasses){
        switch(racismClasses){
            case 1:
                return new Gladiator();
            case 2:
                return new Mage();
            case 3:
                return new Scout();
            default:
                return null;
        }
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public void setIntelligence(int intelligence) {
        this.intelligence = intelligence;
    }

    public void setDexterity(int dexterity) {
        this.dexterity = dexterity;
    }

    public void setEndurance(int endurance) {
        this.endurance = endurance;
    }

    public void setXp(int xp) {
        this.xp = xp;
    }

    public int getStartingPoints() {
        return startingPoints;
    }

    public void setStartingPoints(int startingPoints) {
        this.startingPoints = startingPoints;
    }

    public void setLifeCount(int lifeCount) {
        this.lifeCount = lifeCount;
    }
}
