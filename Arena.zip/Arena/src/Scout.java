public class Scout {
}
