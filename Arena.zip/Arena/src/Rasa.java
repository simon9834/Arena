public interface Rasa {
    public double bonusStrength(double str);
    public double bonusIntelligence(double intel);
    public double bonusEndurance(double endu);
    public double bonusDexterity(double dexte);
}
