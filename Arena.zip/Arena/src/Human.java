public class Human {
}
