public class Gladiator implements Rasa {
    
    private double gladiatorsConstant;
    @Override
    public double bonusStrength(double str) {
        str = str * gladiatorsConstant;
        return str;
    }

    @Override
    public double bonusIntelligence(double intel) {
        intel = intel * gladiatorsConstant;
        return intel;
    }

    @Override
    public double bonusEndurance(double endu) {
        endu = endu * gladiatorsConstant;
        return endu;
    }

    @Override
    public double bonusDexterity(double dexte) {
        dexte = dexte * gladiatorsConstant;
        return dexte;
    }
}
